/*
practice questions:-
X 10 + "20"

X 9 "5"

X 'Java" + "Script" 11

X

11 11 + 11

11 X + 0

X "vinod" "thapa"

X true true

X true false

X false + true

X false - true*/

console.log(10 + "20");