//variables in javascript 
name='deepak';
const id = 1234;
let email='deepak@gh.com;';
var password = 134545;
//var is't use becaue funtion scope or scope;
// id=645; can't use 
email='dff@g.com';
let name1;
let name2=null;
console.table([name,id,email,password,name1,name2]); 
//datatype
let num=344 //Snumber
let vr='vgg' //string
let c= true //boolean
let d= null //null
let e;//undefined 


//conversion of datype

let op= String(num);
console.log(typeof op);